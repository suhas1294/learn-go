package main

import (
	"log"
	"myapp/internal/config"
	"myapp/internal/infrastructure"
	"myapp/internal/router"
)

func main() {
	// Load config
	cfg := config.New()

	// Initialize DB
	db, err := infrastructure.NewSQLiteDB(cfg)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	// Set up router
	r := router.New(db)

	log.Println("Server starting on port 8080")
	if err := r.ListenAndServe(":8080"); err != nil {
		log.Fatal(err)
	}
}
