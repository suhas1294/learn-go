Folder structure : 

myapp/
├── cmd/
│   └── server/
│       └── main.go
├── internal/
│   ├── api/
│   │   └── handler.go
│   ├── config/
│   │   └── config.go
│   ├── domain/
│   │   └── user.go
│   ├── infrastructure/
│   │   └── sqlite_repository.go
│   ├── middleware/
│   │   └── logging.go
│   ├── router/
│   │   └── router.go
│   └── usecase/
│       └── user_usecase.go
├── db/
│   └── schema.sql
├── go.mod
└── go.sum