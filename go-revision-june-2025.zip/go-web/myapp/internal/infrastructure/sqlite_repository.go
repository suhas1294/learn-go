package infrastructure

import (
	"database/sql"
	"myapp/internal/config"
	"myapp/internal/domain"

	_ "modernc.org/sqlite"
)

func NewSQLiteDB(cfg *config.Config) (*sql.DB, error) {
	return sql.Open("sqlite", cfg.DBPath)
}

type SQLiteUserRepository struct {
	DB *sql.DB
}

func (r *SQLiteUserRepository) GetUserByID(id int) (*domain.User, error) {
	row := r.DB.QueryRow("SELECT id, name FROM users WHERE id = ?", id)
	user := &domain.User{}
	if err := row.Scan(&user.ID, &user.Name); err != nil {
		return nil, err
	}
	return user, nil
}
