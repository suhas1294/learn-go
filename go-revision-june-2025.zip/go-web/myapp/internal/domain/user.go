package domain

type User struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}

type UserRepository interface {
	GetUserByID(id int) (*User, error)
}
