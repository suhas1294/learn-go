// https://chatgpt.com/share/683c21db-db64-800f-b248-59e9254f739b
package main

import "fmt"

func foo() {
	for i := 0; i < 10; i++ {
		fmt.Println("foo-", i)
	}
}
func bar() {
	for i := 0; i < 10; i++ {
		fmt.Println("bar-", i)
	}
}

func main() {
	go foo()
	go bar()
	// main function will exit here.
	// main is also goroutine / main thread.
	// When main thread stops, every other goroutine stops as well.

	/*
		concept of wait groups ;
		we declare a wait group at a package level and and use it in goroutine to notify main thread that this task is done.

		import "sync"

		var wg sync.WaitGroup

		func main(){
			wg.add(1) ; // what does this 1 represent? It represents the number of goroutines we are going to wait for.
			go foo();
			bar();
			wg.Wait(); // this will block the main thread until all goroutines are done.
		}

		func foo() {
			defer wg.Done() // this will notify the main thread that this goroutine is done.
			// do something
		}

		Go concurrency tagline :
		"Do not communicate by sharing memory; instead, share memory by communicating."

		Golang is designed in such a way that only one goroutine will have access to a variable at a time.
		which is achieved by using channels.

		// --------------------------------------------------------------------

		Simple illustration of channels :

		func doSomething(x int) int {
			return x * 2
		}

		func main() {
			ch := make(chan int) // create a channel of type int
			go func() {
				ch <- doSomething(5) // send the result of doSomething to the channel
			}()
			fmt.Println(<-ch) // receive the result from the channel
		}

		// --------------------------------------------------------------------

		// Simulating race condition
		import (
			"fmt"
			"runtime"
			"sync"
		)

		func main() {
			fmt.Println("CPUs:", runtime.NumCPU())
			fmt.Println("Goroutines:", runtime.NumGoroutine())

			counter := 0

			const gs = 100
			var wg sync.WaitGroup
			wg.Add(gs)

			for i := 0; i < gs; i++ {
				go func() {
					v := counter
					// time.Sleep(time.Second)
					runtime.Gosched() // this is used to yield the processor, allowing other goroutines to run
					v++
					counter = v
					wg.Done()
				}()
				fmt.Println("Goroutines:", runtime.NumGoroutine())
			}
			wg.Wait()
			fmt.Println("Goroutines:", runtime.NumGoroutine())
			fmt.Println("count:", counter)
		}


		NOTE : to check if race confition exists in a program,
		we can use the `go run -race` command.

		// --------------------------------------------------------------------
		Use of Mutex :

		func main() {
			fmt.Println("CPUs:", runtime.NumCPU())
			fmt.Println("Goroutines:", runtime.NumGoroutine())

			counter := 0

			const gs = 100
			var wg sync.WaitGroup
			wg.Add(gs)

			var mu sync.Mutex

			for i := 0; i < gs; i++ {
				go func() {
					mu.Lock()		// this will lock the further code to be accessed by different goroutines
					// until the current goroutine is done with the code.
					v := counter
					runtime.Gosched()
					v++
					counter = v
					mu.Unlock()		// this will unlock the code, allowing other goroutines to access it.
					// NOTE : if we forget to unlock the code, it will cause a deadlock.
					// A deadlock is a situation where two or more goroutines are waiting for each other to release a lock, causing them to be stuck indefinitely.
					wg.Done()
				}()
				fmt.Println("Goroutines:", runtime.NumGoroutine())
			}
			wg.Wait()
			fmt.Println("Goroutines:", runtime.NumGoroutine())
			fmt.Println("count:", counter)
		}
		// --------------------------------------------------------------------

		Concept of Automic :

		func main() {
			fmt.Println("CPUs:", runtime.NumCPU())
			fmt.Println("Goroutines:", runtime.NumGoroutine())

			var counter int64

			const gs = 100
			var wg sync.WaitGroup
			wg.Add(gs)

			for i := 0; i < gs; i++ {
				go func() {
					atomic.AddInt64(&counter, 1)	// this automic package is user to perform atomic operations on variables. It has methods like AddInt64, LoadInt64, StoreInt64, etc.
					// No need to use mutex when using atomic operations.
					// This means that the operation will be performed atomically, without any other goroutine being able to access the variable at the same time.

					runtime.Gosched()
					fmt.Println("Counter\t", atomic.LoadInt64(&counter)) // this will load the value of counter atomically. (its like a getter method)
					wg.Done()
				}()
				fmt.Println("Goroutines:", runtime.NumGoroutine())
			}
			wg.Wait()
			fmt.Println("Goroutines:", runtime.NumGoroutine())
			fmt.Println("count:", counter)
		}

		// --------------------------------------------------------------------

		Concept of channels :

		this code wont work :

		func main(){
			ch := make(chan int) // create a channel of type int
			ch <- 5 // send the value 5 to the channel
			fmt.Println(<-ch) // receive the value from the channel
			// this will cause a deadlock because the channel is unbuffered and there is no goroutine to receive the value.
		}

		// This will work :
		func main(){
			ch := make(chan int) // create a channel of type int
			go func(){
				ch <- 5 // send the value 5 to the channel
			}()
			fmt.Println(<-ch)
		}

		// concept of buffered channels :
		ch := make(chan int, 2) // create a buffered channel of type int with a capacity of 2
		This channel can hold up to 2 values before it blocks the sending goroutine.

		// Below function will work fine because we are using a buffered channel.
		func main(){
			ch := make(chan int, 1) // create a channel of type int, buffered with a capacity of 1 - this will allow 1 value to sit in there until its pulled out.
			ch <- 5
			fmt.Println(<-ch)
		}

		// Below function will NOT work fine because we are putting 2 values in a channel of capacity 1, which will cause a deadlock.
		func main(){
			ch := make(chan int, 1) // create a channel of type int, buffered with a capacity of 1 - this will allow 1 value to sit in there until its pulled out.
			ch <- 5
			ch <- 10
			fmt.Println(<-ch)
		}

		// Directional channels :
		// A directional channel is a channel that can only be used to send or receive values, but not both.
		// This is useful when you want to restrict the usage of a channel to a specific direction.

		// Sending only channel :
		func main(){
			ch := make(chan <- int, 2) // create a channel of type int, buffered with a capacity of 2, but only for sending values.
			ch <- 5 // this will work fine
			ch <- 10 // this will also work fine
			// fmt.Println(<-ch) // this will cause a compile error because the channel is only for sending values, not receiving.
		}

		// Receiving channel :
		func main(){
			rh := make(<-chan int, 2) // create a channel of type int, buffered with a capacity of 2, but only for receiving values.
			rh <- 5 // this will cause a compile error because the channel is only for receiving values, not sending.
			rh <- 10 // this will also cause a compile error because the channel is only for receiving values, not sending.
			fmt.Println(<-rh) // this will work fine because we are receiving values from the channel.
		}

		// Assigning from specific channel type to general type wont work
		func main(){
			c := make(chan int)
			cs := make(chan <- int) // sending only channel
			cr := make(<-chan int)  // receiving only channel

			c = cs // this will cause a compile error because cs is a sending only channel, not a general channel.
			c = cr // this will also cause a compile error because cr is a receiving only channel, not a general channel.

			// general to specific channel type will work fine
			cs = c // this will work fine because c is a general channel, and we can assign it to a sending only channel.
			cr = c // this will work fine because c is a general channel, and we can assign it to a receiving only channel.
		}

		// --------------------------------------------------------------------

		// sample concurrent program using channels :
		func main(){
			ch  := make(chan int)
			go foo(ch)
			bar(ch)
			fmt.Println("about to exit")
		}

		func foo(ch chan <- int) { // general to specific type, works !
			ch <- 43
		}

		func bar(ch <- chan int) { // specific to general type, works !
			fmt.Println("value received from channel is : ", <-ch) // this will receive the value from the channel
		}

		// --------------------------------------------------------------------

		Ranging over channels :
		One who 'sends' should 'close' the channel.

		func main(){
			ch := make(chan int)

			go func(){
				for i := 0; i < 5; i++ {
					ch <- i * 2 // send values to the channel
				}
				close(ch) // IMPORTANT : close the channel after sending all values
				// without closing, deadlock will happen.
			}()

			for v := range ch { // Keep ranging over the channel until it is closed
				fmt.Println("Received from channel:", v) // this will print the values received from the channel
			}

			fmt.Println("Channel closed, exiting main function")
		}

		// --------------------------------------------------------------------
		// Select statement :

		func main(){
			eve, odd, quit := make(chan int), make(chan int), make(chan int)
			go send(eve, odd, quit)
			receive(eve, odd, quit)
			fmt.Println("Exiting main function")
		}

		func send(eve, odd, quit chan<- int) {
			for i := 0; i < 10; i++ {
				if i%2 == 0 {
					eve <- i // send even numbers to the eve channel
				} else {
				 	odd <- i // send odd numbers to the odd channel
				}
			}
			quit <- 0 // send a signal to quit
		}

		func receive(eve, odd, quit <-chan int) {
			for {
				select {
				case v := <-eve:
					fmt.Println("Received from eve channel:", v) // this will print the values received from the eve channel
				case v := <-odd:
					fmt.Println("Received from odd channel:", v) // this will print the values received from the odd channel
				case <-quit:
					fmt.Println("Received quit signal, exiting receive function")
					return // exit the function when quit signal is received
				}
			}
			// NOTE : if we don't have a quit channel, the program will run indefinitely.
		}

		// --------------------------------------------------------------------
		// Implementation of same program without using quit channel :

		func main() {
			eve, odd := make(chan int), make(chan int)
			go send(eve, odd)
			receive(eve, odd)
			fmt.Println("Exiting main function")
		}

		func send(eve, odd chan int) {
			for i := 0; i < 10; i++ {
				if i%2 == 0 {
					eve <- i
				} else {
					odd <- i
				}
			}
			close(eve)
			close(odd)
		}

		func receive(eve, odd chan int) {
			for {
				select {
				case v, ok := <-eve:
					if ok {
						fmt.Println("Received from eve channel:", v)
					} else {
						eve = nil // disable this case in select
					}
				case v, ok := <-odd:
					if ok {
						fmt.Println("Received from odd channel:", v)
					} else {
						odd = nil // disable this case in select
					}
				}

				if eve == nil && odd == nil {
					fmt.Println("Both channels closed, exiting receive function")
					return
				}
			}
		}
		// IMPORTANT : close(eve) and close(odd) mark the channels as closed,
		// Receivers detect this via ok.
		// --------------------------------------------------------------------

		// Same code using bool channel for quit :

		func main() {
			even, odd := make(chan int), make(chan int)
			quit := make(chan bool)

			go send(even, odd, quit)
			receive(even, odd, quit)

			fmt.Println("about to exit")
		}

		// send channel
		func send(even, odd chan<- int, quit chan<- bool) {
			for i := 0; i < 10; i++ {
				if i%2 == 0 {
					even <- i
				} else {
					odd <- i
				}
			}
			close(quit) // this will send false which will be detected in comma-ok in receive.
			// NOTE : we can also send a value to quit channel, but here we are just closing it.
			// quit <- true // this will send true to the quit channel, which will be detected in receive.
		}

		// receive channel
		func receive(even, odd <-chan int, quit <-chan bool) {
			for {
				select {
				case v := <-even:
					fmt.Println("the value received from the even channel:", v)
				case v := <-odd:
					fmt.Println("the value received from the odd channel:", v)
				case receivedVal, ok := <-quit:
					if !ok {
						fmt.Println("from comma ok", receivedVal, ok)
						return
					} else {
						fmt.Println("from comma ok", receivedVal)
					}
				}
			}
		}

		// --------------------------------------------------------------------

		func main(){
			c := make(chan int)
			go func() {
				c <- 42
			}()
			val, ok := <-c // this will receive the value from the channel and also check if the channel is closed or not
			if ok {
				fmt.Println(val, ok) // output : 42 true
			}
		}
		// --------------------------------------------------------------------

		// --------------------------------------------------------------------
						FAN-IN & FAN-OUT DESIGN PATTERN
		// --------------------------------------------------------------------

		// Fan-in : multiple goroutines sending data to a single channel
		// Fan-out : single goroutine receiving data from multiple channels

		func main() {
			even, odd, fanin := make(chan int), make(chan int), make(chan int)

			go send(even, odd)
			go receive(even, odd, fanin) // Note that even receive function is diff thread unlike above examples

			for v := range fanin {			// range until fanin is closed
				fmt.Println(v)
			}

			fmt.Println("about to exit")
		}

		// send channel
		func send(even, odd chan<- int) {
			for i := 0; i < 100; i++ {
				if i%2 == 0 {
					even <- i
				} else {
					odd <- i
				}
			}
			close(even)
			close(odd)
		}

		// receive channel
		func receive(even, odd <-chan int, fanin chan<- int) {
			var wg sync.WaitGroup
			wg.Add(2)

			go func() {
				for v := range even {
					fanin <- v
				}
				wg.Done()
			}()

			go func() {
				for v := range odd {
					fanin <- v
				}
				wg.Done()
			}()

			wg.Wait()
			close(fanin)
		}

		// --------------------------------------------------------------------
		ROB PIKES CODE FOR ILLUSTRATION OF FAN-IN AND FAN-OUT DESIGN PATTERN
		// --------------------------------------------------------------------

		func main() {
			c := fanIn(boring("Joe"), boring("Ann"))
			for i := 0; i < 10; i++ {
				fmt.Println(<-c)
			}
			fmt.Println("You're both boring; I'm leaving.")
		}

		func boring(msg string) <-chan string {
			c := make(chan string)
			go func() {
				for i := 0; ; i++ {
					c <- fmt.Sprintf("%s %d", msg, i)
					time.Sleep(time.Duration(rand.Intn(1e3)) * time.Millisecond)
				}
			}()
			return c
		}

		// FAN IN
		func fanIn(input1, input2 <-chan string) <-chan string {
			c := make(chan string)
			go func() {
				for {
					c <- <-input1
				}
			}()
			go func() {
				for {
					c <- <-input2
				}
			}()
			return c
		}

		// --------------------------------------------------------------------
		MODIFICATION OF ROB PIKE'S CODE FOR GRACEFUL EXIT
		// --------------------------------------------------------------------

		func main() {
			done := make(chan struct{})
			c := fanIn(done, boring("Joe", done), boring("Ann", done))
			for i := 0; i < 10; i++ {
				fmt.Println(<-c)
			}
			fmt.Println("You're both boring; I'm leaving.")
			close(done)
			time.Sleep(time.Second) // give time for goroutines to exit gracefully
		}

		func boring(msg string, done <-chan struct{}) <-chan string {
			c := make(chan string)
			go func() {
				defer fmt.Println(msg, "cleanup done")
				for i := 0; ; i++ {
					select {
					case c <- fmt.Sprintf("%s %d", msg, i):
						time.Sleep(time.Duration(rand.Intn(1e3)) * time.Millisecond)
					case <-done:
						close(c)
						return
					}
				}
			}()
			return c
		}

		// FAN IN
		func fanIn(done <-chan struct{}, input1, input2 <-chan string) <-chan string {
			c := make(chan string)
			go func() {
				for {
					select {
					case v, ok := <-input1:
						if !ok {
							return
						}
						c <- v
					case <-done:
						return
					}
				}
			}()
			go func() {
				for {
					select {
					case v, ok := <-input2:
						if !ok {
							return
						}
						c <- v
					case <-done:
						return
					}
				}
			}()
			return c
		}

		// --------------------------------------------------------------------
		FAN-OUT DESIGN PATTERN EXAMPLE :
		// --------------------------------------------------------------------

		func main() {
			c1 := make(chan int)
			c2 := make(chan int)

			go populate(c1)

			go fanOutIn(c1, c2)

			for v := range c2 {
				fmt.Println(v)
			}

			fmt.Println("about to exit")
		}

		func populate(c chan int) {
			for i := 0; i < 100; i++ {
				c <- i
			}
			close(c)
		}

		func fanOutIn(c1, c2 chan int) {
			var wg sync.WaitGroup
			for v := range c1 {
				wg.Add(1)
				go func(v2 int) {
					c2 <- timeConsumingWork(v2)
					wg.Done()
				}(v)
			}
			wg.Wait()
			close(c2)
		}

		func timeConsumingWork(n int) int {
			time.Sleep(time.Microsecond * time.Duration(rand.Intn(500)))
			return n + rand.Intn(1000)
		}

		// --------------------------------------------------------------------
		FAN OUT design pattern with Throttling  :
		// --------------------------------------------------------------------

		func main() {
			c1 := make(chan int)
			c2 := make(chan int)

			go populate(c1)

			go fanOutIn(c1, c2)

			for v := range c2 {
				fmt.Println(v)
			}

			fmt.Println("about to exit")
		}

		func populate(c chan int) {
			for i := 0; i < 100; i++ {
				c <- i
			}
			close(c)
		}

		func fanOutIn(c1, c2 chan int) {
			var wg sync.WaitGroup
			const goroutines = 10
			wg.Add(goroutines)

			for i := 0; i < goroutines; i++ { 	// here we are using only 10 threads.
				go func() {
					for v := range c1 {
						func(v2 int) {			// Here we were using go routines in earlier example.
							c2 <- timeConsumingWork(v2)
						}(v)
					}
					wg.Done()
				}()
			}
			wg.Wait()
			close(c2)
		}

		func timeConsumingWork(n int) int {
			time.Sleep(time.Microsecond * time.Duration(rand.Intn(500)))
			return n + rand.Intn(1000)
		}

		// --------------------------------------------------------------------
							Context in go routines :
		Its used to manage the lifecycle of goroutines, especially for cancellation and timeouts.

		In Go servers, each incoming request is handled in its own goroutine. Request
		handlers often start additional goroutines to access backends such as databases and
		RPC services. The set of goroutines working on a request typically needs access to
		request-specific values such as the identity of the end user, authorization tokens,
		and the request’s deadline. When a request is canceled or times out, all the goroutines
		working on that request should exit quickly so the system can reclaim any resources
		they are using.
		// --------------------------------------------------------------------

		Example usage of how to gracefully terminate goroutines using context :

		// example-1 :
		func main() {
			ctx, cancel := context.WithCancel(context.Background())

			fmt.Println("error check 1:", ctx.Err())
			fmt.Println("num gortins 1:", runtime.NumGoroutine())

			go func() {
				n := 0
				for {
					select {
					case <-ctx.Done():
						return
					default:
						n++
						time.Sleep(time.Millisecond * 200)
						fmt.Println("working", n)
					}
				}
			}()

			time.Sleep(time.Second * 2)
			fmt.Println("error check 2:", ctx.Err())
			fmt.Println("num gortins 2:", runtime.NumGoroutine())

			fmt.Println("about to cancel context")
			cancel()
			fmt.Println("cancelled context")

			time.Sleep(time.Second * 2)
			fmt.Println("error check 3:", ctx.Err())
			fmt.Println("num gortins 3:", runtime.NumGoroutine())
		}

		// --------------------------------------------------------------------

		// example-2

		func main() {
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel() // cancel when we are finished

			for n := range gen(ctx) {
				fmt.Println(n)
				if n == 5 {
					break
				}
			}
		}

		func gen(ctx context.Context) <-chan int {
			dst := make(chan int)
			n := 1
			go func() {
				for {
					select {
					case <-ctx.Done():
						return // returning not to leak the goroutine
					case dst <- n:
						n++
					}
				}
			}()
			return dst
		}
		// --------------------------------------------------------------------

		Example - 3 :

		func main() {
			ctx, cancel := context.WithCancel(context.Background())

			go worker(ctx, "A")
			go worker(ctx, "B")

			time.Sleep(3 * time.Second)
			cancel() // cancel all child goroutines
			time.Sleep(1 * time.Second)
			fmt.Println("Main exiting")
		}

		func worker(ctx context.Context, name string) {
			for {
				select {
				case <-ctx.Done():
					fmt.Println("worker", name, "exiting")
					return
				default:
					fmt.Println("worker", name, "working...")
					time.Sleep(500 * time.Millisecond)
				}
			}
		}

		// --------------------------------------------------------------------
		i read one concept - in web application, for every request, there will be diff
		goroutines, and these go routiunes may spin up further goroutines to get other
		jobs done like db accessing, authentication etc. so while doing sub tasks say
		authentication and authorisation, how can a sub go routine which was spun up
		by its parent goroutine, can access cookies data ? u can show me this using
		psuedo code also. basically innermost goroutine access data of its
		parent goroutine - is it via closure


		// real world use case :

		func handler(w http.ResponseWriter, r *http.Request) {
			// Create a context derived from request context
			ctx := r.Context()

			// Extract cookie value
			sessionID, _ := r.Cookie("session_id")

			// Add sessionID to context so sub-goroutines can access it
			ctx = context.WithValue(ctx, "sessionID", sessionID.Value)

			// spawn auth worker goroutine
			go authWorker(ctx)

			// spawn db query worker goroutine
			go dbWorker(ctx)

			fmt.Fprintln(w, "Request handled")
		}

		func authWorker(ctx context.Context) {
			sessionID := ctx.Value("sessionID").(string)
			fmt.Println("Auth worker got sessionID:", sessionID)
		}

		func dbWorker(ctx context.Context) {
			sessionID := ctx.Value("sessionID").(string)
			fmt.Println("DB worker got sessionID:", sessionID)
		}

		summary :
		1. Each HTTP request gets a context.Context (r.Context())
		2. You can add key-value pairs using context.WithValue
		3. When spinning sub-goroutines, you pass the context along
		4. Sub-goroutines can read values via ctx.Value("key")
		5. No need for fragile closure captures, everything is safe via context


	*/
}
