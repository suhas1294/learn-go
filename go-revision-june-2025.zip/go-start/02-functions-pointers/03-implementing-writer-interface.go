/*
	We have this standard interface in Go from the package "io" that is used to write data to a stream.
	// The interface is called Writer and it has a single method Write that
	// takes a byte slice and returns the number of bytes written and an error.

	type Writer interface {
		Write(p []byte) (n int, err error)
	}
*/

package main

import (
	"bytes"
	"io"
	"os"
)

type person struct {
	name string
}

func (p person) WritePerson(w io.Writer) {
	// The Write method of the Writer interface is implemented here
	// It takes a byte slice and returns the number of bytes written and an error
	w.Write([]byte(p.name))
}

func anotherMain() {
	// Create a new person
	p := person{name: "John"}

	// Create a new writer
	f, _ := os.Create("person.txt")
	defer f.Close()

	var b bytes.Buffer

	p.WritePerson(f)  // writing person details into file
	p.WritePerson(&b) // writing person details into buffer

	/*
		Explanation:

		what are we trying to achieve here?
		We are trying to write the person details into a file and a buffer.

		Here both file interface and buffer interface are implementing the Writer interface.
		Both of them have the Write method that takes a byte slice and returns the number of bytes written and an error.

		If we call writePerson method with file interface, it will write the person details into the file.
		If we call writePerson method with buffer interface, it will write the person details into the buffer.
		So, we can use the same method to write to different types of writers.
	*/
}
