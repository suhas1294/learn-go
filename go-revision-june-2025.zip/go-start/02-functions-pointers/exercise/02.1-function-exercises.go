package main

import (
	"fmt"
)

func foo() int {
	return 42
}

func bar() (int, string) {
	return 42, "hello"
}

func foo1(args ...int) int {
	sum := 0
	for _, arg := range args {
		sum += arg
	}
	return sum
}

func bar1(input []int) int {
	sum := 0
	for _, arg := range input {
		sum += arg
	}
	return sum
}

func deferredFunc1() {
	fmt.Println("This is a deferred function-1")
}

func deferredFunc2() {
	fmt.Println("This is a deferred function-2")
}

type person struct {
	name string
	age  int
}

type circle struct {
	radius float64
}

type rectangle struct {
	length float64
	width  float64
}

type shape interface {
	area() float64
}

func (c circle) area() float64 {
	return 3.14 * c.radius * c.radius
}
func (r rectangle) area() float64 {
	return r.length * r.width
}

func info(s shape) {
	fmt.Println("Area:", s.area())
}

func (p person) speak() {
	fmt.Println("My name is", p.name, "and I am", p.age, "years old.")
}

func (p person) greet(fn func(string) string) {
	fmt.Println(fn(p.name))
}

func main() {

	// exercise 3
	defer deferredFunc1()
	defer deferredFunc2()

	// exercise 1
	barInt, barStr := bar()
	fmt.Println(foo(), barInt, barStr)

	// exercise 2
	xi := []int{1, 2, 3}
	foo1(xi...)
	bar1(xi)

	// exercise 4
	p := person{"John", 30}
	p.speak()

	// exercise 5
	c := circle{5}
	r := rectangle{4, 5}
	info(c)
	info(r)

	// exercise 6 : function expression.
	anonFunc := func(a int, b int) int { return a + b }
	fmt.Println(anonFunc(1, 2))

	// exercise 7 : anonymous function
	func() {
		for i := 0; i < 10; i++ {
			fmt.Println(i)
		}
	}()

	p1 := person{"Alice", 25}
	cb := func(name string) string {
		return "Hello, " + name
	}
	p1.greet(cb)
}
