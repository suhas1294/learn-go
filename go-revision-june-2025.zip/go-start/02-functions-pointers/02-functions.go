// https://chatgpt.com/share/682a0db8-d504-800f-9e72-1c0f50329dbf
package main

import "fmt"

// Everything about pointers.

// 1. variadic parameters
// 2. unfurling a slice
// 3. methods, interfaces and polymorphism
// 4. anonymous functions and func expressions
// 5. callbacks and closures

// syntaxes :
/*
	func (receiver type) methodName (parameters) (return types) {
		// method body
	}
	Everything in Go is a pass by value.

	// no params, no return
	func functionName() {
		// function body
	}

	// 1 param, no return
	func functionName(param1 type) {
		// function body
	}

	// 1 param, 1 return
	func functionName(param1 type) (return1 type) {
		// function body
		return return1
	}

	// 2 params, 2 returns
	func functionName(param1 type, param2 type) (return1 type, return2 type) {
		// function body
		return return1, return2
	}

	// DEFER statemet :
	// this is used to delay the execution of a function until the surrounding function returns.
	// this is useful for cleaning up resources, closing files, etc.
	// Whenever the outerfunction(which holds another function with defer in it) returns, the deferred function will be executed.

	METHODS vs FUNCTIONS :
	1. A function is a standalone block of code that can be called from anywhere in the program.
	2. A method is a function that is associated with a specific type (struct) and can be called on an instance of that type.
	3. A method has a receiver, which is the instance of the type that the method is called on.
	4. A function does not have a receiver.
	5. A method can access the fields and methods of the type it is associated with, while a function cannot.

	6. A method can be called on a pointer to the type, which allows it to modify the fields of the type.
	7. A function cannot be called on a pointer to the type.
	8. A method can be called on a nil pointer, which will not cause a panic.
	9. A function cannot be called on a nil pointer, which will cause a panic.

	type person struct {
		name string
		age  int
	}

	func (p person) greet() {
		fmt.Println("Hello, my name is", p.name, " and my age is ", p.age);
	}

	p1: = person{name: "John", age: 30}
	p1.greet() // Hello, my name is John and my age is 30

	INTEERFACE :
	1. An interface is a collection of method signatures that a type must implement in order to satisfy the interface.
	2. An interface does not contain any implementation, only the method signatures.
	3. A type can implement multiple interfaces, and an interface can be implemented by multiple types.

	POLYMORPHISM :
	1. Polymorphism is the ability of a type to take on multiple forms.
	2. In Go, values can be be of more then one type.
	3. In Go, polymorphism is achieved through interfaces.

	type shape interface {
		area() float64
		perimeter() float64
	}
	// --------- --------- --------- --------- ---------
	type circle struct {
		radius float64
	}
	func (c circle) area() float64 {
		return math.Pi * c.radius * c.radius
	}
	func (c circle) perimeter() float64 {
		return 2 * math.Pi * c.radius;
	}
	// --------- --------- --------- --------- ---------
	type rectangle struct {
		length float64
		breadth float64
	}
	func (r rectangle) area() float64 {
		return r.length * r.breadth
	}
	func (r rectangle) perimeter() float64 {
		return 2 * (r.length + r.breadth)
	}
	// --------- --------- --------- --------- ---------
	func printShapeInfo(s shape) {
		fmt.Println("Area:", s.area())
		fmt.Println("Perimeter:", s.perimeter())
	}
	// --------- --------- --------- --------- ---------
	c := circle{radius: 5}
	r := rectangle{length: 10, breadth: 5}
	printShapeInfo(c)
	printShapeInfo(r)

	// --------- --------- --------- --------- ---------
	// Best way to remeber interface :
	// Interface says : "Hey man ! if u implement my methods, you are of my type"


	// toString() overriding | exploring stringer intercace :
	// Its very similar to overriding toString() method in Java.
	type Stringer interface {
		String() string
	}
	type person struct {
		name string
		age  int
	}
	func (p person) String() string {
		return fmt.Sprintf("My name is %s and my age is %d", p.name, p.age);
	}
	p1 := person{name: "John", age: 30}
	fmt.Println(p1.String()) // My name is John and my age is 30
	fmt.Println(p1)          // My name is John and my age is 30

	// --------- --------- --------- --------- ---------

	// WRAPER FUNCTION USING INTERFACE :
	type book interface {
		title string
	}

	type count int;

	func (c count) String() string {
		return fmt.Sprintf("Count is %d", c);
	}

	func (b book) String() string {
		return fmt.Sprintf("Book title is %s", b.title);
	}

	func logCustom(s fmt.Stringer) {
		log.Println("[custom msg from wrapper]: " + s.String());
	}
	book1 := book{title: "Go Programming"}
	count1 := count(10)
	logCustom(book1); // output : [custom msg from wrapper]: Book title is Go Programming
	logCustom(count1); // output : [custom msg from wrapper]: Count is 10

	// --------- --------- --------- --------- ---------
	Anonymous function is a function that is defined without a name.
	func(){code}()
	func (param1 type, param2 type) (return types) {code} ()

	func(s string) {
		fmt.Println("Hello", s)
	}("John");

	// --------- --------- --------- --------- ---------
	Func expressions :

	fe := func(s string) {
		fmt.Println("Hello", s)
	}
	fe("John");

	// --------- --------- --------- --------- ---------
	returning a function from a function :

	func bar() func() int {
		// returning a anonymous function which inturn returns a int
		return func() int {
			return 42
		}
	}

	barFunc := bar()
	fmt.Println(barFunc()) // 42

	// --------- --------- --------- --------- ---------
	// contept of callbacks :

	func add(a int, b int) int {
		return a + b
	}

	func subtract(a int, b int) int {
		return a - b
	}

	func doMath(a int, b int, f func(int, int) int) int {
		return f(a, b)
	}

	doMath(10, 5, add)      // 15
	doMath(10, 5, subtract) // 5

	// --------- --------- --------- --------- ---------
	// concept of closures :

	func incrementer() func() int{
		i := 0
		return func() int {
			i++
			return i
		}
	}

	f := incrementer();
	fmt.Println(f()) // 1
	fmt.Println(f()) // 2
	fmt.Println(f()) // 3

	g := incrementer();
	fmt.Println(g()) // 1
	fmt.Println(g()) // 2
	fmt.Println(g()) // 3

	// --------- --------- --------- --------- ---------

	Wrapper function , example : calculating time taken by a function to execute

	func add(x, y int) int {
		return x + y
	}
	func timeTaken(f func()) {
		start := time.Now()
		f()
		elapsed := time.Since(start)
		fmt.Println("Time taken : ", elapsed)
	}

	timeTaken(func(){
		add(1, 2)
		fmt.Println("Add function executed")
	})

*/

func doNothing() {
	fmt.Println("foo")
}

func printName(s string) {
	fmt.Println("My name is " + s)
}

func getName(s string) string {
	return fmt.Sprintf("They call me %s", s)
}

func getNameWithAlias(fileName int) (string, string) {
	return fmt.Sprintf("File no : %d They call me Bond,", fileName), "James Bond"
}

func greetAllFellows(prefix string, names ...string) {
	for _, name := range names {
		fmt.Println(prefix + " " + name + "!")
	}
}

// ----------- polymorphism start -----------
type shape interface {
	area() float64
	perimeter() float64
}
type circle struct {
	radius float64
}
type rectangle struct {
	length  float64
	breadth float64
}

func (c circle) area() float64 {
	return 3.14 * c.radius * c.radius
}
func (c circle) perimeter() float64 {
	return 2 * 3.14 * c.radius
}
func (r rectangle) area() float64 {
	return r.length * r.breadth
}
func (r rectangle) perimeter() float64 {
	return 2 * (r.length + r.breadth)
}
func printShapeInfo(s shape) {
	fmt.Println("Area:", s.area())
	fmt.Println("Perimeter:", s.perimeter())
}

// ----------- polymorphism end -----------

// function with variadic parameters :
// this prints sum of all the numbers
func funcWithVariadicParams(numbers ...int) int {
	sum := 0
	for _, number := range numbers {
		sum += number
	}
	return sum
}

func main() {

	doNothing()

	printName("John")

	fmt.Println(getName("John"))

	name, alias := getNameWithAlias(007)
	fmt.Println("The Name as per file is  : ", name, " and the alias is : ", alias)

	funcWithVariadicParams(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
	funcWithVariadicParams() // still a valid one !

	ss := []string{"John", "Doe", "Smith"}
	greetAllFellows("Hello", ss...) // this is how you unfurl a slice
	greetAllFellows("Hello")        // still a valid one !

	// ---------
	c := circle{radius: 5}
	r := rectangle{length: 10, breadth: 5}
	printShapeInfo(c)
	printShapeInfo(r)
	// ---------

}
