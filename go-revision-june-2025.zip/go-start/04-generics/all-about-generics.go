package main

import "fmt"

func addI(a, b int) int {
	return a + b
}

func addF(a, b float64) float64 {
	return a + b
}

func addT[T int | float64](a, b T) T {
	return a + b
}

type myNumber interface {
	int | float64
}

func addM[T myNumber](a, b T) T {
	return a + b
}

type myAlias int

func main() {
	fmt.Println(addI(5, 12))
	fmt.Println(addF(12.34, 345.34))

	// making uses of generic types.
	fmt.Println(addT(5, 12))
	fmt.Println(addT(12.34, 345.34))

	fmt.Println(addM(5, 12))
	fmt.Println(addM(12.34, 345.34))

	/*
		var x myAlias = 42
		fmt.Println(addM(x, 23));	// WONT WORK, COMPILE ERROR.

		To fix this, we can redefine the myNumber interface :
		type myNumber interface {
			~int | ~float64
		}

		This tells go compiler to include all values of type (int/float) AND any values who has an underlying value of type (int/float).
	*/

	/*
		Package constraints :

		We need to import "golang.org/x/exp/constraints" to use the constraints package.
		import "golang.org/x/exp/constraints"

		type myNumber interface {
			constraints.Integer | constraints.Float
			// constraints.Integer is a type constraint that includes all integer types (int, int8, int16, int32, int64).
			// constraints.Float is a type constraint that includes all floating-point types (float32, float64).
			// This allows us to use any integer or floating-point type as a type parameter in our generic function.
		}
	*/

	// concrete types vs interface types.
	/*

		concrete type is a type that u can directly instantiate or create a value from.

		Interface type is a type which defines contracts (set of methods or types) but
		does not represent specific data or instance.They represent behaviour or
		type but not specific set of values.

		Comparable interface ;
		https://go.dev/blog/comparable


		The comparable constraint permits any type whose values may be compared
		using == and !=.

		Meaning:

		Allowed: int, float64, string, bool, pointers, structs where all fields
		are comparable, arrays of comparable elements, etc.

		Not Allowed: slices, maps, functions (because you can’t compare those
		with == and != in Go)

		It’s a compiler-enforced constraint built into the type system.

		SUMMARY : It allows types that can be compared using == and !=.

		QUESTION : Why use 'K comparable' instead of 'K any' in generics?
		ANSWER : Map key types in Go must be comparable by language rule.
		Using 'K comparable' allows the compiler to enforce that the type

		FYI :
		type person struct {
			name string
			age int
		}
		p1 := person{name: "Alice", age: 30}
		p2 := person{name: "Alice", age: 30}
		fmt.Println(p1 == p2) // This will print 'true' because both have the same values for name and age

		Official docs : https://go.dev/doc/tutorial/generics
	*/
}
