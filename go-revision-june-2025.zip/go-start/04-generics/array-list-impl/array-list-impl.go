package main

import "fmt"

// Define a generic type ArrayList with type parameter T
type ArrayList[T any] struct {
	items []T
}

// Add an element to the list
func (a *ArrayList[T]) Add(item T) {
	a.items = append(a.items, item)
}

// Get an element at a specific index
func (a *ArrayList[T]) Get(index int) T {
	return a.items[index]
}

// Get length of the list
func (a *ArrayList[T]) Len() int {
	return len(a.items)
}

func main() {
	// Create an ArrayList of int
	intList := ArrayList[int]{}
	intList.Add(10)
	intList.Add(20)

	fmt.Println("First int:", intList.Get(0))
	fmt.Println("Length:", intList.Len())

	// Create an ArrayList of string
	strList := ArrayList[string]{}
	strList.Add("Go")
	strList.Add("Lang")

	fmt.Println("First string:", strList.Get(0))
	fmt.Println("Length:", strList.Len())
}
