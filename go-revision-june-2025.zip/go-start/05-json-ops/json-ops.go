package main

import (
	"encoding/json"
	"fmt"
)

type User struct {
	UserId        int    `json:"userId"`
	Id            int    `json:"id"`
	Title         string `json:"title"`
	Completed     bool   `json:"completed"`
	optionalField string `json:"-"` // This will ignore the field completely

}

/*
Summary about JSON tags :
// Field appears in JSON as key "myName".
Field int `json:"myName"`

// Field appears in JSON as key "myName" and
// the field is omitted from the object if its value is empty,
// as defined above.
Field int `json:"myName,omitempty"`

// Field appears in JSON as key "Field" (the default), but
// the field is skipped if empty.
// Note the leading comma.
Field int `json:",omitempty"`

// Field is ignored by this package.
Field int `json:"-"`

// Field appears in JSON as key "-".
Field int `json:"-,"`
*/

func main() {

	jsonStr := `{
		"userId": 1,
		"id": 1,
		"title": "delectus aut autem",
		"completed": false
		"optionalField": "This is an optional field that is not in the struct"
	  }`

	var p User

	// Unmarshal JSON string into user struct
	err := json.Unmarshal([]byte(jsonStr), &p)
	if err != nil {
		fmt.Println("Error unmarshalling JSON:", err)
		return
	}

	// Print the struct
	fmt.Printf("UserId: %d, Id: %d, Title: %s, Completed: %t\n", p.UserId, p.Id, p.Title, p.Completed)

	// Marshal struct back to JSON
	jsonData, err := json.Marshal(p)
	if err != nil {
		fmt.Println("Error marshalling JSON:", err)
		return
	}

	// Print the JSON string
	fmt.Println(string(jsonData))

	// Converting from strng to bytes :
	// _byteData := []byte(jsonStr)

	// Converting from bytes to string :
	// _stringData := string(_byteData)
	// uint8 is a alias for byte, so you can use it interchangeably.

	/*
		Difference between Marshal/Unmarshal vs Encode/Decode:

		Marshal/Unmarshal: These functions are used to convert Go data structures to and
		from JSON format in memory. They work with byte slices and return the JSON
		representation as a byte slice or parse a byte slice into a Go data structure.

		Encode/Decode: These functions are used to read and write JSON data directly
		from/to an `io.Writer` or `io.Reader`. They are typically used for streaming JSON data
		and can handle larger data sets more efficiently. Encode writes JSON to an `io.Writer`,
		and Decode reads JSON from an `io.Reader`. They do not return byte slices but instead
		read from or write to the provided streams.

		In Summary, Encode and Decode is used to write Directly to the wire.
		Marshal & Unmarshal is used to convert data and store it in variable (memory).
		The wire may refer to network connections, files, or any other.
	*/

	/*
		Sorting slices :

			package main

			import (
				"fmt"
				"sort"
			)

			type Person struct {
				Name string
				Age  int
			}

			func (p Person) String() string {
				return fmt.Sprintf("%s: %d", p.Name, p.Age)
			}

			// ByAge implements sort.Interface for []Person based on
			// the Age field.
			type ByAge []Person

			func (a ByAge) Len() int           { return len(a) }
			func (a ByAge) Swap(i, j int)      { a[i], a[j] = a[j], a[i] }
			func (a ByAge) Less(i, j int) bool { return a[i].Age < a[j].Age }

			// Less(i, j) says: “Should i come before j?”
			// < → Ascending
			// > → Descending

			func main() {
				people := []Person{
					{"Bob", 31},
					{"John", 42},
					{"Michael", 17},
					{"Jenny", 26},
				}

				fmt.Println(people)
				// There are two ways to sort a slice. First, one can define
				// a set of methods for the slice type, as with ByAge, and
				// call sort.Sort. In this first example we use that technique.
				sort.Sort(ByAge(people))
				fmt.Println(people)

				// The other way is to use sort.Slice with a custom Less
				// function, which can be provided as a closure. In this
				// case no methods are needed. (And if they exist, they
				// are ignored.) Here we re-sort in reverse order: compare
				// the closure with ByAge.Less.
				sort.Slice(people, func(i, j int) bool {
					return people[i].Age > people[j].Age
				})
				fmt.Println(people)

			}

			Multi field sorting :
			If you ever need multi-field sorting (like sort by Age, and if same Age,
			sort by Name), you can chain conditions in Less:

			sort.Slice(people, func(i, j int) bool {
				if people[i].Age == people[j].Age {
					return people[i].Name < people[j].Name
				}
				return people[i].Age < people[j].Age
			})
	*/
}
