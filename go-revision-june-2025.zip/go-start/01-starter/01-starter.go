package main

// import "fmt"		// importing in single line

import (			// importing in multi line
	"fmt"
)

func main() {
	const name , age = "John", 30;		// assignment of multiple variables in single line
	fmt.Println("Hello, World!");
	fmt.printf("Hello, %s! You are %d years old.\n", name, age);

	// how to know type of variable
	fmt.Printf("Type of name: %T\t and type of age is : %T", name, age);

	/* 
	Computer works on switches : On (1) and Off (0)
	It can be used to represent any data. for example : 
	
	Coding scheme : 
	00 : bring pizza
	01 : bring burger
	10 : bring sandwich
	11 : bring salad

	roughly translating above as coding scheme, way back world was not having standard coding
	scheme : 
	ex : 00 meant 'bring pizza' in india, but it could mean 'bring burger' in other country.

	So there was a need of standard coding scheme : 
	ASCII was one one them in earlier days. it used to represent data by using 8 bits. (7 bits for data and 1 bit for parity)
	ASCII can represent 256 characters. (2 ^ 8, where 8 is number of bits)
	For example, '01000100' is the binary representation of 'D' in ASCII.
	Since ASCII can represent only 256 characters, it is not sufficient for all languages.
	
	Then came UNICODE, which can represent 65536 characters. (2 ^ 16, where 16 is number of bits)

	Then came UTF-8, which is a variable length encoding scheme. It can represent 1 to 4 bytes of data.
	It stores Unicode as binary data.
	If a character needs 1 byte, it will use 1 byte. If a character needs 2 bytes, it will use 2 bytes.
	This makes it efficient in terms of memory.
	Rare characters like doubel heart emoji (💕) takes 32 bits or 4 bytes.
	UTF-8 is backward compatible with ASCII. So, all ASCII characters are also valid UTF-8 characters.
	UTF-8 is the most widely used encoding scheme in the world. 
	 */


	//  printing raw string literals ; 
	fmt.Println(`Hello, 
		Bharath!,
		Jai Jagganath!
	`);


	// Go user manual vs Effective Go  : two different documents
	// Go user manual is for beginners and Effective Go is for advanced users.

	// TODO: know meaning of "source code is unicode represented in UTF-8"

	// ----------------------------------------------------
	// variables, Zero values , Blank identifier.
	// ----------------------------------------------------

	// Variable : A VARIABLE holds a VALUE of a specific TYPE.
	var sjbf int = 102; // this also assigns the value to the variable.

	//  another way is to use short declaration operator ':='
	// it allows to declare and assign a variable in one line.
	sljfb := 102; // this also assigns the value to the variable.

	// multiple assignments ; 
	asd, ads, _ , asdjlnas := 1, 2, "blank identifier", 4; // this also assigns the value to the variable.
	// here, _ is a blank identifier. It is used to ignore the value of the variable.
	// it is useful when you want to ignore something out of many things a function returns.
	// for example, if a function returns 3 values and you want to ignore the second value, you can use _.

	/*
	
	NOTE: unused variables are not allowed in Go. Compiler will throw an error if you try to use an unused variable.

	NOTE: General guideline : use short declaration operator ':=' when possible.
	When to use var keyword? :
	1. when you want to declare a variable without assigning a value to it.
	2. when you want to declare a variable with a specific type.
	3. when you want to declare a variable in a package scope.
	4. when you want to declare a variable in a function scope.
	5. when you want to declare a variable in a loop.
	6. when you want to declare a variable in a conditional statement.
	7. when you want to declare a variable in a switch statement.
	8. when you want to declare a variable in a select statement.
	9. when you want to declare a variable in a defer statement.

	NOTE:  Unassigned variables are given a zero value. (default value)
	Default values for pointers, functions, interfaces, slices, channels, maps is nil.
	

	values, types, conversions, scope,
	Casting in other languages is called conversion in Go.
	%v is kind of supeset for all types. It is used to print the value of a variable.
	official syntax for conversion : T(x) where T is the type and x is the value.
	short declaration can be used only inside functions.
	There is no variable hoisting in Go. So, you cannot use a variable before it is declared.

	Built in types, aggregate types, composite types.
	> package 'builtin'.
	> built in types : int, float, string, bool, complex.
	> aggretate types : array, struct, slice, map.
	> composite/compound types : struct, interface

	import (
		"fmt"
		"math/rand"
	)
	fmt.Println(rand.Intn(100)) // this will print a random number between 0 and 99. 
	// Intn generated number between [0, n) where n is the number passed to it.
	fmt.Println("name is", name, "and age is", age); // Println takes multiple 'n' number of arguments. variadic parameter.
	
	We dont use the words 'public and private' in Go. We use 'exported and unexported'.

	// -----------------------------------------------------
	Functions : 
	// -----------------------------------------------------

	function add(a int, b int) int { // function with return type
		return a + b;
	}

	// this can be shortened to
	function addAnother(a, b int) int { // function with multiple return type
		return a + b;
	}

	// function can return multiple values.
	function addAndSubtract(a, b int) (int, int) {
		return a + b, a - b;
	}

	function swap(a, b string) (string, string) {
		return b, a;
	}

	Go's return type can be named aka Naked return type.
	function addAndSubtract(a, b int) (sum int, diff int) {
		sum = a + b;
		diff = a - b;
		return
	}

	a var keyword can be at function level or package level.
	uniniaialized variables are given a zero value.

	const d int = 10; // constant variable
	var i, isPresent bool; // multiple variable declaration, uninitialised

	// TODO: Bill kenedy , const has special properties - parallel type system

	// IMPORTANT: IF VARIABLES ARE INITIALISED, THEN TYPE CAN BE OMITTED.
	example : var i, j = 1, 2; // this is valid ; No need to say its int. 

	'rune' is another word for 'char' in other languages.
	// rune is an alias for int32. It is used to represent a Unicode code point.

	uint8 = unsigned int of 8 bits
	byte is an alias for uint8. It is used to represent a byte.

	variable declarations can be 'factored' into blocks : 
	var (
		ToBe bool = false
		MaxInt uint64 = 1<<64 - 1
		holdsNothing string
		z complex128 = cmplx.Sqrt(-5 + 12i) // import "math/cmplx"
	)
	unsigned is positive number.

	var i = 22 // this is valid. value on right determines the type of variable on left.

	// IMPORTANT: consts cannnot be declared with ':='
	*/

	const (
		c0 = iota // 0
		c1 = iota // 1
		c2 = iota // 2
	)

	const (
		c3 = iota // 0
		c4
		c5
		c6
	)

	const (
		_ = iota // 0
		a
		b
		c
		d
		e
	)

	fmt.Println(c0, c1, c2, c3, c4, c5, c6); // 0 1 2 0 1 2 3
	fmt.Println("%d \t  %b\n", 1, 1); // 1 1
	fmt.Println("%d \t  %b\n", 1<<a, 1 << a); // 1 1
	fmt.Println("%d \t  %b\n", 1<<b, 1 << b); // 2 10
	fmt.Println("%d \t  %b\n", 1<<c, 1 << c); // 4 100
	fmt.Println("%d \t  %b\n", 1<<d, 1 << d); // 8 1000
	fmt.Println("%d \t  %b\n", 1<<e, 1 << e); // 16 10000

	/*
	type ByteSize int;
	const (
		_ = iota;
		KB ByteSize = 1 << (10 * iota) // 1 << (10 * 0) = 1
		MB
		GB
		TB
		PB
		EB
	)
	fmt.Println(KB, MB, GB, TB, PB, EB); // 1024 1048576 1073741824 1099511627776 1125899906842624 1152921504606846976
	fmt.Printf("%d \t %b\n", KB, KB); // 1024 10000000000
	fmt.Printf("%d \t %b\n", MB, MB); // 1048576 100000000000000000000
	fmt.Printf("%d \t %b\n", GB, GB); // 1073741824 100000000000000000000000000
	fmt.Printf("%d \t %b\n", TB, TB); // 1099511627776 100
	fmt.Printf("%d \t %b\n", PB, PB); // 1125899906842624 100
	fmt.Printf("%d \t %b\n", EB, EB); // 1152921504606846976 100

	//TODO: Run hash256 (google for 'sha256 checksum mac command') algorithm on a string and get the hash value.


	// creating projects in the local : 
	go mod init <module_name> // this will create a go.mod file in the current directory.

	GOOS : Go Operating System
	GOARCH : Go Architecture
	go env GOARCH GOOS // this will print the current OS and architecture.
	GOOS=darwin GOARCH=amd64 go build -o hello hello.go // this will build the hello.go file for darwin OS and amd64 architecture.

	GOPATH VS GOROOT : 
	GOPATH is the path where your Go projects are stored. It is set to $HOME/go by default.
		- this contains the source code, binaries and packages. (bin, pkg, src)
	GOROOT is the path where Go is installed. It is set to /usr/local/go by default.

	GOPATH is no more required in Go 1.11 and later.
		- Go modules are used to manage dependencies. (go.mod file)
		- Go modules are used to manage packages. (go.sum file)
	
	go.mod is equivalent to package.json in Node.js.
	go.sum is equivalent to package-lock.json in Node.js.

	In go, if statements, you can declare variables in the if statement itself.
	example :
	if i := 10; i > 0 {
		fmt.Println("i is positive");
	} else {
	 		fmt.Println("i is negative");
	}
			
	Comma-ok idiom :
	if i, ok := m["key"]; ok {
		fmt.Println("key exists");
	}

	go env : lists all the environment variables used by go, includes GOROOT and GOPATH.

	'go get' is a tool that lets you download and install packages from the internet.
	'go mod tidy' is a tool that lets you remove unused packages from the go.mod file and also add missing packages to the go.mod file which is used in the code.


	What makes something visible outside the pacakge or not depends on whether its exported or not.
	Exported means it starts with a capital letter. Unexported means it starts with a small letter.
	Note : package = folder

	sample usage : packageName.FunctionName();

	download all dependencies without cleaning: `go mod download`.
	go mod tidy : clean all dependencies and download only the required ones. (updates those which are updated in go.mod file)

	// -----------------------------------------------------

	Versioning:
	git tag 
	git tag vN.N.N (this is called semantic versioning : Major::Minor::Patch)
	git push origin --tags

	Major : need not be backward compatible. (breaking changes)
	Minor : backward compatible. (new features)
	Patch : backward compatible. (bug fixes)

	// -----------------------------------------------------

	Go program has concept of 'init' function.
	- this function is called before the main function.
	- this function is used to initialize the package.
	
	// -----------------------------------------------------
	
	statement, statement idiom : 
	if a, b, c := 1, 2, 3; a+b+c > 5 {
		fmt.Println("sum > 5")
	}

	practical examples : 
	
	1. Error handling during file open
	if file, err := os.Open("config.json"); err != nil {
		log.Fatal(err)
	} else {
		defer file.Close()
		// use file
	}

	2. Reading a config or environment variable : 
	if value, ok := os.LookupEnv("PORT"); ok {
		fmt.Println("Port is", value)
	} else {
		fmt.Println("PORT not set")
	}

	3. JSON unmarshalling
	if err := json.Unmarshal(data, &config); err != nil {
		log.Println("Invalid JSON:", err)
	}

	4. Map lookup pattern
	if val, ok := myMap["key"]; ok {
		fmt.Println("Found value:", val)
	}

	5. Reading data in a loop
	for line, err := reader.ReadString('\n'); err == nil; line, err = reader.ReadString('\n') {
		fmt.Println(line)
	}
	
	// -----------------------------------------------------

	Comma-ok idiom :
	In Go, some operations(or functions) return two values:
	- the actual result
	- a boolean indicating success

	value, ok := something[key_or_input]
	
	NOTE : It’s not universal to all functions — only functions or operations 
	designed to return (value, ok)

	examples ; 
	- Map lookups
		myMap := map[string]int{
			"one": 1,
			"two": 2,
		}

		if val, ok := myMap["three"]; ok {
			fmt.Println("Found:", val)
		} else {
			fmt.Println("Key not found")
		}

	- Type assertions
		var i interface{} = "hello"

		if s, ok := i.(string); ok {
			fmt.Println("It's a string:", s)
		} else {
			fmt.Println("Not a string")
		}
		Without this check, an invalid type assertion would panic.


	- Environment variable lookups

	- Channels (value, ok := <-channel)
		ch := make(chan int)
		close(ch)

		if val, ok := <-ch; ok {
			fmt.Println("Received:", val)
		} else {
			fmt.Println("Channel closed")
		}
		When a channel is closed, you still receive the zero value of its type, 
		so the ok tells you whether the channel was open when you received.

	// -----------------------------------------------------

	select statement :
	- The select statement is like a switch statement, but for channels.
	- It allows you to wait on multiple channel operations.
	example : 
		select { 
		case msg := <-ch1:
			fmt.Println("Received from ch1:", msg)
		case msg := <-ch2:
			fmt.Println("Received from ch2:", msg)
		}
		
	// -----------------------------------------------------
	For loops (3 syntaxes) : 

	1. for init ; condition; post {}
	2. for condition {} // like a c while loop.
	3. for { } // infinite loop

	For-range loop :
	- It is used to iterate over arrays, slices, maps, strings, and channels.
	- It returns two values: the index/key and the value.
	- It is a shorthand for the traditional for loop.
	- It is more readable and less error-prone.
	- It is used to iterate over collections.

	xi = []int{1, 2, 3, 4, 5};
	for i, v := range xi {
		fmt.Println(i, v);
	}

	m := map[string]int{
		"one": 1, 
		"two": 2
	};
	for k, v := range m {
		fmt.Println(k, v);
	}
	// NOTE: if you only need the value, you can use the blank identifier to ignore the key.
	// for _, v := range m {
	// 	fmt.Println(v);
	// }

	NOTE : Map does not guarantee the order of iteration.

	// -----------------------------------------------------

	Slice vs arrays : 
	- Slice is a dynamic array, while array is a fixed size array.
	- Slice is a reference type, while array is a value type.
	- Slice has a length and capacity, while array has a fixed length.
	
	Array is mostly used internally by go, we dont use it much often in our code 
	unless we know the size of the array.

	While declaring array, if we want compiler to figure out the size of the array, we can use '...' instead of size.
	a := [...]int{1, 2, 3, 4, 5}; // this will create an array of size 5.

	var c [2]int;
	c[0] = 1;
	c[1] = 2;
	fmt.Println(c); // [1 2]


	fmt.Println("Length of array is", len(c)); // 2

	All about slices : 
	xi := []int{1, 2, 3, 4, 5}; // this will create a slice of size 5.
	xs := []string{"a", "b", "c", "d", "e"}; // this will create a slice of size 5.

	// variadic parameter for append function.
	xi = append(xi, 6, 4, 234, 546, 567, 234, 456); // this will append the values to the slice.

	*/
	
	// slicing a slice : 
	xi := []int{0,1,2,3,4,5,6,7,8,9};
	xi = xi[1:3]; // this will create a new slice with the values from index 1 to 3.
	/* [inclusive: exclusive]
	[:exclusive] : this will create a new slice with the values from index 0 to exclusive.
	[inclusive:] : this will create a new slice with the values from index inclusive to end of the slice.
	[:] : this will create a new slice with the values from index 0 to end of the slice. IN a way cloning the slice.
	*/

	// deleting in a slice using append function.
	xi = append(xi[:2], xi[3:]...); // this will delete the value at index 2.
	// here '...' is called unfurling, its similar to spread operator in JS.

	// Make function : 
	// it is used to create a slice with a specific length and capacity.
	xim := make([]int, 5, 10); // this will create a slice of size 5 and capacity 10.
	fmt.println(cap(xim)); // 10
	fmt.println(len(xim)); // 5



	si := make([]int, 2, 10)
	fmt.Println("Hello, size, capicity : ", len(si), cap(si))
	for i, v := range si {
		fmt.Println("index : ", i, "\tvalue : ", v)
	}
	fmt.Println()
	si = append(si, 3498, 3479, 234)
	for i, v := range si {
		fmt.Println("index : ", i, "\tvalue : ", v)
	}
	/* output : 
	Hello, size, capicity :  2 10
	index :  0 	value :  0
	index :  1 	value :  0

	index :  0 	value :  0
	index :  1 	value :  0
	index :  2 	value :  3498
	index :  3 	value :  3479
	index :  4 	value :  234

	si[5] = 1000 // this will throw an error because the slice is not big enough to hold the value.
	U can only append !!
	*/

	// slice of slice : 
	radioActiveElements := []string{"H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne"};
	metalElements := []string{"Li", "Be", "B", "C", "N", "O", "F", "Ne"};
	nonMetalElements := []string{"H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne"};

	allElements := [][]string{radioActiveElements, metalElements, nonMetalElements};
	fmt.Println(allElements); // this will print the slice of slices.

	// all about maps
	var m map[string]int; // this will create a map with string as key and int as value.
	// m = make(map[string]int); // another way to create map using make function.
	m["one"] = 1; // this will add the key value pair to the map.
	m["two"] = 2; // this will add the key value pair to the map.
	fmt.Printf("%#v\n", m); // this will print the map.

	// randing over map : 
	for k, v := range m {
		fmt.Println("key : ", k, "\tvalue : ", v);
	}
	// NOTE: if you only need the value, you can use the blank identifier to ignore the key.

	// deleting an element from map :
	delete(m, "one"); // this will delete the key value pair from the map.
	// NOTE : trying to delete a non existing key will NOT throw an error(PANIC).
	// NOTE : trying to access a non existing key will return the zero value of the type.
	// right way to check if key exists or not is to use comma-ok idiom.
	// example :
	if val, ok := m["one"]; ok {
		fmt.Println("key exists");
	} else {
		fmt.Println("key does not exist");
	}

	// structs
	type person struct {
		first string
		last string
		age int
	}

	p2 := person{first: "Jane", last: "Doe", age: 25}; // this will create a struct with the values.
	p1 := person{"John", "Doe", 30}; // this will create a struct with the values.

	// NOTE : diff b/w %v, %+v, %#v
	fmt.Printf("%v\n", p1)   // Output: {John Doe 30}
	fmt.Printf("%+v\n", p1)  // Output: {first:John last:Doe age:30}
	fmt.Printf("%#v\n", p1)  // Output: main.person{first:"John", last:"Doe", age:30}

	// Embedded structs :
	type address struct {
		city string
		state string
		country string
	}

	type person struct {
		first string
		last string
		age int
		address address // this will create a struct with the values.
	}

	type secretAgent struct {
		person // this will create a struct with the values.
		licenseToKill bool
	}

	sa1 := secretAgent{
		person{"James", "Bond", 35}, 
		true,
	}; // this will create a struct with the values.

	sa2 := secretAgent{
		person: person{
			"Jane", 
			"Doe", 
			25
		},
		licenseToKill: true,
	}

	fmt.Println(sa1); // this will print the struct.
	// NOTE : if you want to access the fields of the embedded struct, you can do it directly.
	fmt.Println(sa1.first); // this will print the first name of the person.
	fmt.Println(sa1.address.city); // this will print the city of the address.
	// NOTE : If there is one struct inside another struct, the inner fields get promoted to the outer struct.

	// anonymous struct :
	p3 := struct {
		first string
		last string
		age int
	}{
		first: "John",
		last: "Doe",
		age: 30,
	}; // this will create a struct with the values.
	fmt.Printf("%T\n", p3); // this will print out anonymous struct type.

	// creating custom types : 
	type foo int;

	var x foo = 42; // this will create a custom type with the value.
	
	// IMPORTANT :  In go we dont instantiate a type, we create a value of that type.

	// NOTE : Oraganise fields in struct in such a way : large to small. this helps in performance

	// -----------------------------------------------------
}

