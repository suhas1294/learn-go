package main

import (
	"fmt"
)

type User struct {
	Name string
	Age  int
}

type UserManager struct {
	Users []User
}

func (um *UserManager) AddUser(user User) {
	um.Users = append(um.Users, user)
}

func (um *UserManager) IncrementAgeOfAllUsers() {
	for i := range um.Users {
		um.Users[i].Age++
	}
}

func (um *UserManager) FindUserByName(name string) *User {
	for i := range um.Users {
		if um.Users[i].Name == name {
			return &um.Users[i]
		}
	}
	return nil
}

func (um UserManager) printUsers() {
	for i := range um.Users {
		fmt.Print(um.Users[i], "\t")
	}
}

func (u User) printUser() {
	fmt.Println(u, "\n[Printed user]")
}

func (um *UserManager) RemoveUser(name string) {
	ul := um.Users
	removeIdx := -1
	for i := range ul {
		if ul[i].Name == name {
			removeIdx = i
			break
		}
	}
	if removeIdx < 0 {
		return
	}

	newUsers := append([]User{}, ul[:removeIdx]...)
	newUsers = append(newUsers, ul[removeIdx+1:]...)
	um.Users = newUsers
}

func main() {
	u1 := User{Name: "john", Age: 34}
	u2 := User{Name: "cena", Age: 56}
	u3 := User{Name: "rock", Age: 72}
	var us []User
	us = append(us, u1, u2, u3)
	um := UserManager{Users: us}
	um.IncrementAgeOfAllUsers()
	um.printUsers()

	uf := um.FindUserByName("cena")
	if nil != uf {
		uf.Age = 66
	}
	uf.printUser()
	um.printUsers() //See if changes reflect in the original UserManager
	um.RemoveUser("rock")
	um.printUsers()
}

/*
You’ll build a small user manager with a User struct and a UserManager struct.

📦 Requirements:
Define a User struct:

type User struct {
    Name string
    Age  int
}
Define a UserManager struct which holds a list of users:

type UserManager struct {
    Users []User
}
Write a method AddUser that adds a user to the manager.

Think carefully: should this method have a pointer receiver or value receiver?

Write a method IncrementAgeOfAllUsers that increments the age of each user by 1.

Here’s the trick:
a) First, write it incorrectly using value semantics.
b) Observe the result.
c) Then, fix it using pointer semantics where necessary.

Write a method FindUserByName(name string) that returns a pointer to the user if found, or nil if not.

Remember: returning a pointer to a struct inside a slice is allowed — think about slice internals.

In main():

Create a UserManager

Add a few users

Increment their ages

Print the results

Try modifying the age of a user returned by FindUserByName

See if changes reflect in the original UserManager

(Optional tough one)
Implement RemoveUser(name string) method.

Think carefully about how slice copying and index removal affects your struct.

See if you need value or pointer receivers.

💣 Constraints:
Do not use global variables.

No map — only slices.

No third-party libraries.

Observe carefully how data mutates when passing by value vs pointer.

✳️ Bonus Thought:
At each step — before running the code, predict what’ll happen based on your value vs pointer understanding.
If something behaves differently, debug and revise your mental model.

📍 End Goal:
By the end of this, you’ll have:

Mastered when to use value vs pointer receivers.

Experienced Go’s explicit mutability control.

Handled references in slices (which is an area where many Go learners trip up).
*/
