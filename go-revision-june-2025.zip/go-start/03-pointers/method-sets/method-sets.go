package main

import "fmt"

type dog struct {
	name string
}

func (d dog) bark() {
	fmt.Println("Woof! My name is", d.name)
}

func (d *dog) barkMore() {
	fmt.Println("Woof! My name is", d.name, "and I bark more!")
}

type brucelee interface {
	bark()
	barkMore()
}

func karate(b brucelee) {
	fmt.Println("\nKarate time!")
	b.bark()
	b.barkMore()
}

func main() {
	d := dog{name: "Buddy"}

	// example-1
	fmt.Println("\n------ example-1 ------")
	d.bark() // this is straight forward, understandable

	// example-2
	fmt.Println("\n------ example-2 ------")
	d.barkMore()
	/*
		here, inside barkMore, we are calling 'd.name', when u call d.barkMore(),
		barkMore() expects a pointer type(address), but we are sending direct value,
		we cant dereference a value, so it will not work. but how it works ?

		answer ;
		-> d is a named variable and hence addressable.
		-> Go automatically converts d.barkMore() to (&d).barkMore() behind the scenes.
		-> So yes — even though barkMore() expects a pointer, Go auto-addresses an addressable value.


	*/

	dpointer := dog{name: "Max"}
	dAddress := &dpointer

	// example-3 :
	fmt.Println("\n------ example-3 ------")
	dAddress.bark() // Go will internally dereference 'dAddress' and call bark on it, so this will work.

	// example-4 :
	fmt.Println("\n------ example-4 ------")
	dAddress.barkMore() // this is straight forward, understandable

	/*
		thing : dAddress
		type : pointer to value
		method sets : bark() and barkMore()
		does this satisy brucelee interface ? : Yes, because it has both methods bark() and barkMore()

		thing : d
		type : value
		method sets : bark() only
		does this satisy brucelee interface ? : No, because it does not have barkMore() method

		Keeping this in mind, lets try to call karate example :
	*/

	// karate(d) // expected compilation error. and its understandable.
	karate(dAddress) // this will work, because dAddress has both methods bark() and barkMore()
}
