package main

/*
https://chatgpt.com/share/683aab63-5d6c-800f-9c0e-8f12e3dea843
*/
func main() {
	/*
		Say we have  :
		x := 42

		"x" gives us the value of x, however :

		We have three different operators :
			1. "&x" gives us the address of x
				[address of x in memory]
			2. *int : type of '&x' is '*int' (pointer to an int)
				[return type of '&x']
			3. "*x" gives us the value at the address of x
				[dereference the pointer]
			3.1. "*&x" gives us the value at the address of x, which is 42.

		Beforehand : Know the difference between "pass by value", "pass by reference" and "reference type"

		In go lang, following data structures are refernce types :
		1. Slices
		2. Maps
		3. Channels
		4. Functions
		5. Interfaces
		6. Pointers

		Meaning : When we pass the reference type to a function, we are passing the address of the value in memory, not the value itself.
		example :

		func mapDelta(m map[string]int, i int) {
			m["a"] = 749
		}
		func main() {
			m := map[string]int{"a": 1, "b": 2}
			mapDelta(m, 1) // So HERE when we pass 'm' to function, implicitly we are passing the address of 'm' in memory.
			// So when we change the value of 'm' in function, it will change the value of 'm' in main function as well.
			fmt.Println(m) // map[a:749 b:2]
		}

		Only above data structures are reference types, rest
		(primitive data types like int, string, float, boolean ) all are value types.

		func intDelta(i int) {
			i = 749;
		}
		func intDeltaAddress(i *int) {
			*i = 749;
		}
		func main() {
			i := 1

			// case-1  : AKA pass by value AKA VALUE SEMANTIC IN GOLANG
			intDelta(i) // So HERE when we pass 'i' to function, implicitly we are passing the value of 'i' in memory.
			// So when we change the value of 'i' in function, it will NOT change the value of 'i' in main function as well.
			fmt.Println(i) // 1

			// case-2 : AKA reference type AKA POINTER SEMANTIC IN GOLANG
			intDeltaAddress(&i) // So HERE when we pass '&i' to function, implicitly we are passing the address of 'i' in memory.
			// So when we change the value of 'i' in function, it will change the value of 'i' in main function as well.
			fmt.Println(i) // 749
		}

		When you write:
		type User struct {
			Name string
			Age  int
		}
		And then:
		u := User{"John", 30}
		u is an actual value.

		When you pass u to a function:
		-> A copy of the entire struct is made (including its fields).
		-> If you want to avoid copying and mutate the original, you must pass a pointer:

		Go prefers value semantics by default (simpler, safer, easier reasoning about ownership, no implicit references flying around).

		One more peculiar problem related to slice although slice is a reference type :

		func addNumber(s []int) {
			s = append(s, 100) // underlying array might change
		}
		func main() {
			s := []int{1, 2, 3}
			addNumber(s)
			fmt.Println(s) // still [1, 2, 3]
		}

		Why? Because s inside addNumber is a copy of the slice header (ptr, len, cap).
		When capacity overflows, a new array is created — and the copy inside the function now points to the new array, but original in main is unchanged.

		TAGLINE : In golang, you choose mutability by using pointers.

		When to use what ?
		1. use value semantics when possible (u dont have to worry about memory management)
		2. use pointer semantic for larger data structures (like slices, maps, structs) to avoid copying the entire data structure.
		3. use pointer semantic for mutability (when you want to change the value of the data structure in the function)


		type dog struct{
			name string
		}

		func (d dog) bark() {
			fmt.Println("Woof! My name is", d.name)
		}

		func (d *dog) barkMore() {
			fmt.Println("Woof! My name is", d.name, "and I bark more!")
		}
		func main() {
			d1 := dog{name: "Buddy"}
			d1.bark()        // Woof! My name is Buddy
			d1.barkMore()   // Woof! My name is Buddy and I bark more! //TODO: why this works ?

			d2 := &dog{name: "Max"}
			d2.bark()        // Woof! My name is Max //TODO: why this works ?
			d2.barkMore()   // Woof! My name is Max and I bark more!
		}

		// ---------------------------------------------------------------
		// CONCEPT OF METHOD SET IN GOLANG
		// ---------------------------------------------------------------

		In Go, a 'method set' is the set of methods attached to a type. This concept is key to the
		Go's interface mechanism, and it is associated with both the value types and pointer types.

		● The method set of a type T consists of all methods with receiver type T.
			○ These methods can be called using variables of type T.

		● The method set of a type *T consists of all methods with receiver *T or T
			○ These methods can be called using variables of type *T.
			○ it can call methods of the corresponding non-pointer type as well

			The idea of the method set is integral to how interfaces are implemented and used in Go.
		An interface in Go defines a method set, and any type whose method set is a superset of the
		interface's method set is considered to implement that interface.

			A crucial thing to remember is that in Go, if you define a method with a pointer receiver, the
		method is only in the method set of the pointer type. This is important in the context of
		interfaces because if an interface requires a method that's defined on the pointer (not the
		value), then you can only use a pointer to that type to satisfy the interface, not a value of the
		type.

		// ---------------------------------------------------------------

		type dog struct{
			name string
		}

		func (d dog) bark() {
			fmt.Println("Woof! My name is", d.name)
		}

		func (d *dog) barkMore() {
			fmt.Println("Woof! My name is", d.name, "and I bark more!")
		}

		type youngin interface {
			bark()
			barkMore()
		}

		function youngBark(y youngin) {
			y.bark()
		}

		func main() {
			d1 := dog{name: "Buddy"}
			d1.bark()        // Woof! My name is Buddy
			d1.barkMore()   // Woof! My name is Buddy and I bark more! //TODO: why this works ?

			youngBark(d1) // output : COMPILATION ERROR : cannot use d1 (type dog) as type youngin in argument to youngBark:
			// because d1 is of type dog, and dog does not implement the interface youngin

			d2 := &dog{name: "Max"}
			d2.bark()        // Woof! My name is Max //TODO: why this works ?
			d2.barkMore()   // Woof! My name is Max and I bark more!

			youngBark(d2) // output : Woof! My name is Max
			// because d2 is of type *dog, and *dog implements the interface youngin
		}

		// ---------------------------------------------------------------
		SUMMARY OF METHOD SET:
		In simpler terms:

		definition of method set :
		The collection of methods that a value of that type can call directly, which
		determines whether it satisfies a given interface.

		If you have a value of type dog, you can only call methods attached to (d dog).

		If you have a pointer of type *dog, you can call both:
			● Methods attached to (d *dog)
			● Methods attached to (d dog)

		👉 Why can a pointer call value methods?
		Because Go can automatically dereference the pointer to access the value and
		call the method. But it won’t automatically create a pointer if you only have
		a value and try to call a pointer method — that’s a one-way street.

		| Variable | Type   | Method Set             | Implements `youngin`?    |
		| :------- | :----- | :--------------------- | :----------------------- |
		| `d1`     | `dog`  | `bark()`               | ❌ (missing `barkMore()`) |
		| `d2`     | `*dog` | `bark()`, `barkMore()` | ✅                        |

		| Type   | Method Set           | Can Call                                  | Can Satisfy Interface            |
		| :----- | :------------------- | :---------------------------------------- | :------------------------------- |
		| `dog`  | `{ bark }`           | `bark()`, `barkMore()` *(if addressable)* | Only interfaces needing `bark()` |
		| `*dog` | `{ bark, barkMore }` | `bark()`, `barkMore()`                    | Any interface needing both       |


		// ---------------------------------------------------------------

		Receivers 				Values
		-----------------------------------------------
		(t T) 					T and *T
		(t *T) 					*T

		"The method set of a type determines the INTERFACES that the type implements....."

		✅ Simple way to "read" the table:
		If method has (t T) receiver:
			You can call it on a T value.
			You can call it on a *T — because Go will auto-deref the pointer to T for you.

		If method has (t *T) receiver:
			You can only call it on a *T
			You cannot call it on a T unless it’s addressable, in which case Go can auto-take its address.

		Illustration :

		type Dog struct {
			name string
		}

		// Value receiver
		func (d Dog) Bark() {
			fmt.Println("Woof from", d.name)
		}

		// Pointer receiver
		func (d *Dog) BarkMore() {
			fmt.Println("Loud woof from", d.name)
		}

		func main() {
			d := Dog{name: "Buddy"}
			p := &d

			// ------ Method with value receiver (d Dog) Bark --------
			d.Bark() // ✅ allowed: value calling value receiver
			p.Bark() // ✅ allowed: pointer calling value receiver (Go auto-dereferences)

			// ------ Method with pointer receiver (d *Dog) BarkMore --------
			p.BarkMore() // ✅ allowed: pointer calling pointer receiver

			// d.BarkMore() // ⚠️ sometimes allowed if 'd' is addressable — but in pure table rule: not allowed
			// Example of Non-Addressable Value:
			// Dog{"Rocky"}.BarkMore()   // ❌ compile error — cannot take address of composite literal
		}


		// ---------------------------------------------------------------


	*/
}
